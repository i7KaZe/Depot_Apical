<?php
/* Template Name: Page de Formations */

get_header();

$args = array(
    'post_type' => 'post',
);
$query = new WP_Query($args);

if ($query->have_posts()) :
    while ($query->have_posts()) : $query->the_post();

        the_title();
        the_content();
    endwhile;
endif;

get_footer();
?>

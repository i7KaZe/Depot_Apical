<?php
get_header();
include 'formations.php';
get_footer();
?>

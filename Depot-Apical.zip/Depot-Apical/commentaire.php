


<div id="commentairesfiche" class="boutonsbas">
    <div class="ajoutercommentaire">

        <div class="card">
            <div class="card-header">
                Ajouter une note personnelle ou un commentaire
            </div>
            <div class="card-body">
                <form method="post" id="formulaire-commentaire" action="https://apical.xyz/commentaires/2379/2976">
                    <input type="hidden" name="_token" value="K4rIwE0qoK9VBYL2lScdtnnxtHejXFb7MPQLBaF2">
                    <textarea id="commentaire" name="commentaire"></textarea>
                    <div class="form-group row">
                        <div class="col-sm-12 form-check">

                            <input class="form-check-input" type="radio" id="auditoire2" name="auditoire_id" value="2"
                                   checked>
                            <label class="libelleradio form-check-label" for="auditoire2">
                                Note personnelle

                            </label>
                        </div>
                        <div class="col-sm-12 form-check">

                            <input class="form-check-input" type="radio" id="auditoire1" name="auditoire_id" value="1">
                            <label class="libelleradio form-check-label" for="auditoire1">
                                Commentaire public

                            </label>
                        </div>
                        <div class="col-sm-12 form-check">

                            <input class="form-check-input" type="radio" id="auditoire3" name="auditoire_id" value="3">
                            <label class="libelleradio form-check-label" for="auditoire3">
                                Commentaire pour le personnel enseignant

                            </label>
                        </div>
                    </div>
                    <a href="#" class="btn btn-secondary enregistrercommentaire">Envoyer</a>
                </form>
            </div>
        </div>
    </div>
</div>